from flask import Flask, render_template, request, redirect, url_for, flash
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Needed for flash messages

# Home route (renders the HTML form)
@app.route('/')
def home():
    return render_template('index.html')

# Contact form submission route
@app.route('/contact', methods=['POST'])
def contact():
    if request.method == 'POST':
        # Get form data
        name = request.form['name']
        email = request.form['email']
        phone = request.form['number']
        message = request.form['message']

        # Send email using the helper function
        success = send_email(name, email, phone, message)

        if success:
            flash("Your message has been sent successfully!", "success")
        else:
            flash("Failed to send your message. Please try again later.", "error")

        return redirect(url_for('home'))

# Function to send email
def send_email(name, email, phone, message):
    sender_email = os.getenv("EMAIL")
    receiver_email = "vaibhav.innovatehive@gmail.com"
    password = os.getenv("vaibhav@IH3103")

    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = receiver_email
    msg['Subject'] = "New Contact Form Submission from Veer Fitness Website"

    body = f"""
    New contact form submission:

    Name: {name}
    Email: {email}
    Phone: {phone}
    Message: {message}
    """

    msg.attach(MIMEText(body, 'plain'))

    try:
        with smtplib.SMTP('smtp.gmail.com', 587) as server:
            server.starttls()
            server.login(sender_email, password)
            server.sendmail(sender_email, receiver_email, msg.as_string())
        print("Email sent successfully!")
        return True
    except Exception as e:
        print(f"Error sending email: {e}")
        return False

# Run the app
if __name__ == '__main__':
    app.run(debug=True)
